# NEOS Tech Stack

## Project Type

Governance specification + AI skill stack. Primarily markdown documents with supporting Python scripts.

## Primary Deliverable Format

- **Development**: Git repository
- **Distribution**: Zip export of skill modules with top-level README

## Languages

| Language | Purpose |
|----------|---------|
| Markdown | All skill definitions (SKILL.md), reference docs, templates, README |
| YAML | Frontmatter in SKILL.md files, configuration schemas |
| Python 3.14 | Validation scripts, schema checkers, automation tools |

## Skill File Format

```
skill-name/
├── SKILL.md          # YAML frontmatter + markdown instructions (< 500 lines)
├── scripts/          # Python scripts for deterministic tasks
├── references/       # Docs loaded into context as needed
└── assets/           # Templates, schemas, examples (markdown, YAML)
```

## Repository Structure

```
NewEarth/
├── README.md                     # Top-level overview and usage guide
├── NEOS_PRINCIPLES.md            # The 10 non-negotiable structural principles
├── STRESS_TEST_PROTOCOL.md       # The 7 stress-test scenarios
├── neos-core/                    # All skill layers
│   ├── layer-01-agreement/
│   │   ├── agreement-creation/
│   │   │   ├── SKILL.md
│   │   │   ├── scripts/
│   │   │   ├── references/
│   │   │   └── assets/
│   │   ├── agreement-amendment/
│   │   └── ...
│   ├── layer-02-authority/
│   ├── layer-03-act-engine/
│   ├── layer-04-economic/
│   ├── layer-05-inter-unit/
│   ├── layer-06-conflict/
│   ├── layer-07-safeguard/
│   ├── layer-08-emergency/
│   ├── layer-09-memory/
│   └── layer-10-exit/
├── reference-docs/               # Source documents (docx, md)
├── scripts/                      # Global utility scripts
│   ├── validate_skill.py         # Validates SKILL.md structure
│   ├── stress_test_report.py     # Generates stress-test summary
│   └── package_zip.py            # Creates distribution zip
├── conductor/                    # Conductor project management
└── .gitignore
```

## Tooling

- **Python 3.14** — available at `c:/Python314/python`
- **Git** — version control
- **Claude Code** — AI-assisted development and skill authoring

## Schema Validation

Each SKILL.md must pass validation against the required 12-section structure (A through L). A Python validator script will enforce this.

## No External Dependencies

The skill stack itself has zero runtime dependencies. Python scripts use only stdlib. The deliverable is self-contained markdown + YAML.
