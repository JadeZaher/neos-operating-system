# NEOS Tracks

## Implementation Order

Tracks are ordered by layer number for sequential implementation. Each track's dependencies are satisfied by tracks above it.

```
1. Layers I + III (Foundation)     ← no dependencies
2. Layer II (Authority & Role)     ← depends on #1
3. Layer IV (Economic Coord)       ← depends on #1, #2
4. Layer V (Inter-Unit Coord)      ← depends on #1, #2, #3
5. Layer VI (Conflict & Repair)    ← depends on #1, #2
6. Layer VII (Safeguard & Capture) ← depends on #1
7. Layer VIII (Emergency Handling)  ← depends on #1, #6
8. Layer IX (Memory & Trace)       ← depends on #1
9. Layer X (Exit & Portability)    ← depends on #1, #6, #7
10. Global Packaging               ← depends on all
```

---

## Active Tracks

### 1. [ ] foundation_20260301 -- Layers I + III: Agreement Layer + ACT Decision Engine
**Priority:** P0
**Layers:** I (Agreement), III (ACT Decision Engine)
**Status:** Planned
**Created:** 2026-03-01

Build the two foundational NEOS skill layers that everything else depends on. 11 governance skills across 2 layers, plus a global validation script and layer integration.

**Skills (11):**
- [ ] agreement-creation (Layer I) -- P0 anchor
- [ ] agreement-amendment (Layer I)
- [ ] agreement-review (Layer I)
- [ ] agreement-registry (Layer I)
- [ ] universal-agreement-field (Layer I) -- P0 anchor
- [ ] act-advice-phase (Layer III)
- [ ] act-consent-phase (Layer III)
- [ ] act-test-phase (Layer III)
- [ ] proposal-creation (Layer III) -- P0 anchor
- [ ] proposal-resolution (Layer III)
- [ ] consensus-check (Layer III)

**Phases:**
- [ ] Phase 1: Tooling and Scaffolding (validate_skill.py, directory structure, template)
- [ ] Phase 2: Anchor Skills (agreement-creation, proposal-creation)
- [ ] Phase 3: UAF + ACT Core Phases (universal-agreement-field, act-advice, act-consent, act-test)
- [ ] Phase 4: Amendment, Consensus, Review (agreement-amendment, consensus-check, agreement-review)
- [ ] Phase 5: Registry and Resolution (agreement-registry, proposal-resolution)
- [ ] Phase 6: Layer Integration and Finalization (READMEs, cross-review, quality gates)

**Spec:** `conductor/tracks/foundation_20260301/spec.md`
**Plan:** `conductor/tracks/foundation_20260301/plan.md`

---

### 2. [ ] authority_role_20260302 -- Layer II: Authority & Role
**Priority:** P0
**Layers:** II (Authority & Role)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** foundation_20260301

Build 7 governance skills for domain definition (S3 11-element contract), role assignment, boundary negotiation, role transfer, domain review, role sunset, and member lifecycle. Includes a foundation integration phase that updates all 11 Layer I and III skills with formal authority references, resolving the structural weakness identified in the foundation review. Primary framework: Sociocracy 3.0 domain model. Secondary: Holacracy, Laloux Teal.

**Skills (7):**
- [ ] domain-mapping (Layer II) -- P0 anchor
- [ ] member-lifecycle (Layer II) -- P0
- [ ] role-assignment (Layer II) -- P0
- [ ] authority-boundary-negotiation (Layer II) -- P0
- [ ] role-transfer (Layer II)
- [ ] domain-review (Layer II)
- [ ] role-sunset (Layer II)

**Phases:**
- [ ] Phase 1: Scaffolding and Anchor Skill (domain-mapping)
- [ ] Phase 2: Member Lifecycle and Role Assignment (member-lifecycle, role-assignment)
- [ ] Phase 3: Boundary Negotiation and Role Transfer (authority-boundary-negotiation, role-transfer)
- [ ] Phase 4: Domain Review and Role Sunset (domain-review, role-sunset)
- [ ] Phase 5: Layer Integration and README (foundation updates, cross-review)
- [ ] Phase 6: Quality Gate

**Spec:** `conductor/tracks/authority_role_20260302/spec.md`
**Plan:** `conductor/tracks/authority_role_20260302/plan.md`

---

### 3. [ ] economic_coord_20260302 -- Layer IV: Economic Coordination
**Priority:** P1
**Layers:** IV (Economic Coordination)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** foundation_20260301, authority_role_20260302

Build 5 governance skills for resource requests, funding pool stewardship, participatory allocation, commons monitoring, and access economy transition. Grounded in Ostrom's 8 commons governance principles with OmniOne Current-See and H.A.R.T. system as inline examples.

**Skills (5):**
- [ ] resource-request (Layer IV) -- P0 anchor
- [ ] funding-pool-stewardship (Layer IV) -- P0
- [ ] participatory-allocation (Layer IV)
- [ ] commons-monitoring (Layer IV)
- [ ] access-economy-transition (Layer IV)

**Phases:**
- [ ] Phase 1: Scaffolding and Anchor Skills (resource-request, funding-pool-stewardship)
- [ ] Phase 2: Participatory Allocation
- [ ] Phase 3: Commons Monitoring
- [ ] Phase 4: Access Economy Transition and Layer Integration

**Spec:** `conductor/tracks/economic_coord_20260302/spec.md`
**Plan:** `conductor/tracks/economic_coord_20260302/plan.md`

---

### 4. [ ] inter_unit_20260302 -- Layer V: Inter-Unit Coordination
**Priority:** P1
**Layers:** V (Inter-Unit Coordination)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** foundation_20260301, authority_role_20260302, economic_coord_20260302

Build 5 governance skills for cross-AZPO requests, shared resource stewardship, federation agreements, inter-unit liaison roles, and polycentric conflict navigation. Grounded in Ostrom's polycentric governance, millet system structural pattern (minus the Sultan), and Holochain agent-centric architecture.

**Skills (5):**
- [ ] cross-azpo-request (Layer V) -- P0 anchor
- [ ] shared-resource-stewardship (Layer V) -- P0
- [ ] federation-agreement (Layer V)
- [ ] inter-unit-liaison (Layer V)
- [ ] polycentric-conflict-navigation (Layer V)

**Phases:**
- [ ] Phase 1: Scaffolding and Anchor Skill (cross-azpo-request)
- [ ] Phase 2: Shared Resources and Federation (shared-resource-stewardship, federation-agreement)
- [ ] Phase 3: Liaison Roles and Conflict Navigation (inter-unit-liaison, polycentric-conflict-navigation)
- [ ] Phase 4: Layer Integration and Finalization

**Spec:** `conductor/tracks/inter_unit_20260302/spec.md`
**Plan:** `conductor/tracks/inter_unit_20260302/plan.md`

---

### 5. [ ] conflict_repair_20260302 -- Layer VI: Conflict and Repair
**Priority:** P1
**Layers:** VI (Conflict and Repair)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** foundation_20260301, authority_role_20260302

Build 6 governance skills for harm circles, NVC dialogue, repair agreements, escalation triage, coaching interventions, and community impact assessment. Grounded in Transformative Justice, Restorative Justice, NVC, and Ostrom's accessible conflict resolution principle. OmniOne's Solutionary Culture as inline example.

**Skills (6):**
- [ ] harm-circle (Layer VI) -- P0 anchor
- [ ] nvc-dialogue (Layer VI) -- P0
- [ ] escalation-triage (Layer VI) -- P0
- [ ] repair-agreement (Layer VI)
- [ ] coaching-intervention (Layer VI)
- [ ] community-impact-assessment (Layer VI)

**Phases:**
- [ ] Phase 1: Scaffolding and Core Processes (harm-circle, nvc-dialogue)
- [ ] Phase 2: Escalation Triage
- [ ] Phase 3: Repair Agreements and Coaching (repair-agreement, coaching-intervention)
- [ ] Phase 4: Community Impact Assessment
- [ ] Phase 5: Layer Integration and Finalization

**Spec:** `conductor/tracks/conflict_repair_20260302/spec.md`
**Plan:** `conductor/tracks/conflict_repair_20260302/plan.md`

---

### 6. [ ] safeguard_capture_20260302 -- Layer VII: Safeguard & Capture Detection
**Priority:** P0
**Layers:** VII (Safeguard & Capture Detection)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** foundation_20260301

Build 5 governance skills for continuous governance health monitoring and structural capture resistance. Draws on Michels' Iron Law of Oligarchy, V-Dem Democracy Indicators, and research on capital, charisma, emergency, and ossification capture types. Skills observe, measure, and trigger safeguards when governance health degrades.

**Skills (5):**
- [ ] governance-health-audit (Layer VII) -- P0 anchor
- [ ] capture-pattern-recognition (Layer VII) -- P0
- [ ] safeguard-trigger-design (Layer VII)
- [ ] independent-monitoring (Layer VII)
- [ ] structural-diversity-maintenance (Layer VII)

**Phases:**
- [ ] Phase 1: Scaffolding and Anchor Skill (governance-health-audit)
- [ ] Phase 2: Pattern Recognition and Trigger Design (capture-pattern-recognition, safeguard-trigger-design)
- [ ] Phase 3: Monitoring and Diversity (independent-monitoring, structural-diversity-maintenance)
- [ ] Phase 4: Layer Integration and Finalization

**Spec:** `conductor/tracks/safeguard_capture_20260302/spec.md`
**Plan:** `conductor/tracks/safeguard_capture_20260302/plan.md`

---

### 7. [ ] emergency_handling_20260302 -- Layer VIII: Emergency Handling
**Priority:** P0
**Layers:** VIII (Emergency Handling)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** foundation_20260301, safeguard_capture_20260302

Build 5 governance skills implementing Agamben-resistant emergency governance with circuit breaker states (Closed/Normal, Open/Crisis, Half-Open/Recovery) and mandatory auto-reversion. Every mechanism makes permanence structurally impossible. Follows the emergency lifecycle chronologically.

**Skills (5):**
- [ ] emergency-criteria-design (Layer VIII) -- P0 anchor
- [ ] pre-authorization-protocol (Layer VIII) -- P0
- [ ] crisis-coordination (Layer VIII)
- [ ] emergency-reversion (Layer VIII)
- [ ] post-emergency-review (Layer VIII)

**Phases:**
- [ ] Phase 1: Scaffolding and Entry Criteria (emergency-criteria-design, pre-authorization-protocol)
- [ ] Phase 2: Crisis Operations (crisis-coordination)
- [ ] Phase 3: Reversion and Review (emergency-reversion, post-emergency-review)
- [ ] Phase 4: Layer Integration and Finalization

**Spec:** `conductor/tracks/emergency_handling_20260302/spec.md`
**Plan:** `conductor/tracks/emergency_handling_20260302/plan.md`

---

### 8. [ ] memory_trace_20260302 -- Layer IX: Memory & Traceability
**Priority:** P0
**Layers:** IX (Memory & Traceability)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** foundation_20260301

Build 5 governance skills for decision recording, precedent search, semantic tagging, agreement versioning, and precedent challenge. Defines a generic decision-record wrapper that accommodates any governance artifact from any layer. Primary framework: legal precedent system (stare decisis). Secondary: DAO governance memory, Git-style versioning.

**Skills (5):**
- [ ] decision-record (Layer IX) -- P0 anchor
- [ ] semantic-tagging (Layer IX)
- [ ] precedent-search (Layer IX) -- P0
- [ ] agreement-versioning (Layer IX)
- [ ] precedent-challenge (Layer IX)

**Phases:**
- [ ] Phase 1: Scaffolding and Anchor Skill (decision-record)
- [ ] Phase 2: Semantic Tagging and Precedent Search (semantic-tagging, precedent-search)
- [ ] Phase 3: Agreement Versioning and Precedent Challenge (agreement-versioning, precedent-challenge)
- [ ] Phase 4: Layer Integration and README (retroactive tagging plan, foundation notes, cross-review)
- [ ] Phase 5: Quality Gate

**Spec:** `conductor/tracks/memory_trace_20260302/spec.md`
**Plan:** `conductor/tracks/memory_trace_20260302/plan.md`

---

### 9. [ ] exit_portability_20260302 -- Layer X: Exit & Portability
**Priority:** P0
**Layers:** X (Exit & Portability)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** foundation_20260301, safeguard_capture_20260302, emergency_handling_20260302

Build 5 governance skills ensuring exit is a structural right with graceful degradation and data portability. The capstone functional layer referencing all earlier layers. Draws on Hirschman's Exit/Voice/Loyalty, GDPR Article 20 data portability, cooperative dissolution precedents, and graceful degradation engineering.

**Skills (5):**
- [ ] voluntary-exit (Layer X) -- P0 anchor
- [ ] commitment-unwinding (Layer X)
- [ ] portable-record (Layer X) -- P0
- [ ] azpo-dissolution (Layer X)
- [ ] re-entry-integration (Layer X)

**Phases:**
- [ ] Phase 1: Scaffolding and Individual Exit (voluntary-exit, commitment-unwinding)
- [ ] Phase 2: Data Portability (portable-record)
- [ ] Phase 3: Collective Exit and Re-Entry (azpo-dissolution, re-entry-integration)
- [ ] Phase 4: Layer Integration and Finalization

**Spec:** `conductor/tracks/exit_portability_20260302/spec.md`
**Plan:** `conductor/tracks/exit_portability_20260302/plan.md`

---

### 10. [ ] global_packaging_20260302 -- Global Packaging & Cross-Layer Integration
**Priority:** P0
**Layers:** (cross-cutting)
**Status:** Planned
**Created:** 2026-03-02
**Depends on:** All 9 skill layer tracks

Produce global deliverables wrapping the NEOS skill stack into a distributable, verifiable package: README.md, NEOS_PRINCIPLES.md, STRESS_TEST_PROTOCOL.md, package_zip.py, stress_test_report.py, cross-layer dependency verification, and full skill index.

**Deliverables (6):**
- [ ] README.md
- [ ] NEOS_PRINCIPLES.md
- [ ] STRESS_TEST_PROTOCOL.md
- [ ] scripts/package_zip.py
- [ ] scripts/stress_test_report.py
- [ ] VERSION + full skill index

**Phases:**
- [ ] Phase 1: Reference Documents (NEOS_PRINCIPLES.md, STRESS_TEST_PROTOCOL.md)
- [ ] Phase 2: Utility Scripts (package_zip.py, stress_test_report.py)
- [ ] Phase 3: README and Skill Index
- [ ] Phase 4: Cross-Layer Verification
- [ ] Phase 5: Final Quality Gate and Release Packaging

**Spec:** `conductor/tracks/global_packaging_20260302/spec.md`
**Plan:** `conductor/tracks/global_packaging_20260302/plan.md`

---

## Completed Tracks

(none)
